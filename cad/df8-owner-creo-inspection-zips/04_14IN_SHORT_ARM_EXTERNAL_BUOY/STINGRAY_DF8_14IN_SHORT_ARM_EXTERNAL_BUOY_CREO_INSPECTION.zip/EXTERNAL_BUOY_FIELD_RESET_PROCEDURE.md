# External Buoy Field Reset Procedure

| Step | Action | Classification |
|---:|---|---|
| 1 | recover the device | operator field reset |
| 2 | make the pressure source safe | operator field reset |
| 3 | remove spent cartridge(s) | replace-on-use |
| 4 | rearm or replace water activation element(s) | replace-on-use |
| 5 | inspect inflator(s) | field maintenance |
| 6 | inspect and dry buoy | field maintenance |
| 7 | deflate buoy fully | operator field reset |
| 8 | fold buoy to the controlled packed envelope | operator field reset |
| 9 | route the tether | operator field reset |
| 10 | route manual lanyard(s) | operator field reset |
| 11 | position inflator module(s) in protective pocket(s) | operator field reset |
| 12 | close Cordura flaps | operator field reset |
| 13 | set controlled hook-and-loop overlap | operator field reset |
| 14 | secure pull-tab keeper | operator field reset |
| 15 | reset arms | operator field reset |
| 16 | reset locks/stowed retention | operator field reset |
| 17 | inspect recovery hardware | field maintenance |
| 18 | perform leak/function check | field maintenance |
| 19 | return to ready-to-throw state | operator field reset |

Damage to the buoy membrane, welded pack anchors, hardpoint, shell, or recovery yoke is **depot damage repair**. An inflator that fails inspection is **replace-on-failure**. Spent cartridge(s) and fired water activator(s) are **replace-on-use**. Return to service requires controlled cartridge/activator identity, correct tab exposure, direct mesh water path, prescribed closure overlap, recovery-hardware inspection, and successful leak/function checks.
