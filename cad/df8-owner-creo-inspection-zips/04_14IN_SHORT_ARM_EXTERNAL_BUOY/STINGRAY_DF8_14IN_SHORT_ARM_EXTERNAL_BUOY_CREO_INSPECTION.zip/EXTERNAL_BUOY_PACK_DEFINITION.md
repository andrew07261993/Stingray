# External Buoy Pack Definition

## Configuration

- Assembly: `Aft_Buoy_Breakaway_Wrap_CORDURA`
- Material: **CORDURA SOFTGOODS — MATERIAL SPECIFICATION PROVISIONAL**
- Closed wrap OD: 128.000 mm
- Maximum ready-state OD including pull tabs: 152.400 mm
- Axial extent: 305.000 mm (1320.000 to 1625.000 mm from nose tip)
- Forward shoulder rise: 35.200 mm; transition angle 32.619°
- Circumferential coverage: 360° through cradle plus opposed overlapping flaps

## Installed construction

Eight welded titanium eyes attach two closed body webbing loops to the retained Grade-9 shell. The Cordura cradle, two longitudinal peel flaps, six tapered transition panels, four sensor meshes, four drain meshes, reinforced hinge seams, four manual-lanyard grommets, four anti-snag keepers, and two pairs of segmented hook-and-loop strips are modeled as positive-thickness closed solids. Four module guards restrain the inflator systems while remaining open to water and axial cartridge service.

The pack stores, protects, and retains the buoy. It is excluded from the primary recovery load path. The source-backed structural harness, captive thimbles/pins, HMPE tether, and integral short-aft hardpoint carry recovery load.

## State behavior

STOWED has the folded buoy inside a controlled packed envelope, closed flaps, exposed sensor meshes, externally accessible pull tabs, and retained tether routing. DEPLOYED retains every physical pack component, rotates the two flaps to their peel-open transforms, relocates the source-backed buoy gores to the inflated state, and extends the structural tether. Only the documentation-only packed-envelope proxy is absent from DEPLOYED.

## Service and unresolved controls

Exact Cordura denier/coating, seam thread and stitch traveler, wet hook-and-loop peel data, exact buoy fold, module holder/support, manufacturer water-entry keep-out, and proprietary module geometry remain controlled replacement/test gates. No proprietary geometry is claimed by the `_PROXY` definitions.
