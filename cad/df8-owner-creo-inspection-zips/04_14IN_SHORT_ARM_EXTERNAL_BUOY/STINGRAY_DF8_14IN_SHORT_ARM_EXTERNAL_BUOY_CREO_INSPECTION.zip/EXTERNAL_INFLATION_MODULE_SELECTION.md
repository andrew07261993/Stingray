# External Inflation Module Selection

Selected developmental path: **United Moulders Limited MK5 automatic/manual family, UMA4012/D160**, represented with the existing Spinlock **DW-CYD60 60 g system path**.

| Field | Installed developmental value |
|---|---|
| Manufacturer/family | United Moulders Limited MK5 automatic/manual |
| Controlled MPN | UMA4012/D160 family path |
| Cartridge path | Spinlock DW-CYD60 / DW-RAK/275 system path; exact cylinder sub-MPN unresolved |
| Nominal CO₂ per module | 60.0 g |
| Module count | 4 |
| Total nominal CO₂ | 240.0 g |
| Source staged-buoyancy cold/full-surface requirement | 229.627609 g |
| Inventory margin | 10.372391 g |
| Automatic trigger | Four independent buoy-mounted water activator proxies behind direct open mesh |
| Manual pull | Four grouped, externally accessible individual pull tabs; no unsupported common high-pressure manifold |
| Buoy interface | Four reinforced manufacturer-compatible manifold-patch proxies |
| Service | Axial cartridge/module replacement envelopes; pack repacking opening retained |

This selection closes a developmental external packaging path; it is not qualification. Exact complete-assembly CAD, cartridge sub-MPN, standalone holder/support, outlet/manifold compatibility, water-entry envelope, required pull travel, certificate status, and application approval remain vendor gates. The internal 50.700 mm-bore study is not reopened and does not reject this external architecture. No purchase is authorized or recorded.
