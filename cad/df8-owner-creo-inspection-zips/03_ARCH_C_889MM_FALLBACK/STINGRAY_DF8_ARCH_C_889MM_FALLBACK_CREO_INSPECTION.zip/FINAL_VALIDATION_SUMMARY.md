# Final validation summary

Disposition: **MEASURED NON-PASS CHECKPOINT**

- Endpoint exact validation: PASS; zero changed-scope unauthorized interferences.
- Five-angle exact gate (0/20/40/55/80 deg): PASS; zero unauthorized pairs or blocked Booleans.
- Full optimized 0..80 deg audit: PASS; each angle evaluated exactly once; zero unauthorized pairs or blocked Booleans.
- Exact AP242 OCP/XCAF clean reimport: PASS for both states; exact BREP, AP242, hierarchy and millimetre units retained.
- Mass: 14.237204 kg; reserve 3.902796 kg.
- Rigid length: 2032.000 mm.
- Pressure-architecture OD: 56.900 mm.
- Whole STOWED hard-geometry diameter: 63.263027 mm — FAIL versus 57.15 mm due retained aft recovery/service hardware.
- Locked station: FAIL. Exact measured maximum-forward checkpoint is 889.000 mm nose-tip-to-pivot / 549.000 mm from FWD-RING-01, after two authorized correction passes.
- Functional COTS: 16/24 = 66.67% — below 70% and truthfully retained.
