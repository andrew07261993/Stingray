# Breakaway Pack Opening Screen

Disposition: **PASS — DEVELOPMENTAL FORCE/GEOMETRIC SCREEN — PHYSICAL WET-INFLATION TEST MANDATORY**

The two opposed flaps open by progressive peel, not full-area shear. Four 70 mm axial closure segments create a modeled peel-front arc width of 11.170 mm each. With provisional wet peel resistance of 0.250–0.750 N/mm, the total predicted resistance is 11.170–33.510 N.

Using an initial effective inflation area of 20000 mm² and 2.5–5.0 kPa differential pressure gives 50.000–100.000 N. The conservative screen margin is 1.492.

These inputs are provisional engineering ranges, not controlled hook-and-loop data. Acceptance requires wet coupons and a fully packed inflation test that demonstrates water activation, initial expansion, sequential peel, unthrottled buoy unfolding, tether exit without fouling, and pack retention on the body.
