# Short-Arm Mission Envelope Comparison

Status: **OWNER-REQUESTED SHORT-ARM DEVELOPMENTAL ALTERNATIVE — PHYSICAL FABRIC-ENGAGEMENT AND RETENTION TEST REQUIRED**

| Quantity | Validated forward-arm reference | Developmental short-arm | Change |
|---|---:|---:|---:|
| Pivot-to-tip arm length | 733.806 mm | 378.206 mm | -355.600 mm |
| Deployed radial tip reach | 740.657838 mm | 390.460201 mm | -350.197637 mm (47.282%) |
| Deployed axial tip projection | 127.424075 mm | 65.674783 mm | -61.749292 mm |
| Three-tip span | 1282.857006 mm | 676.296907 mm | -606.560100 mm |
| Idealized engagement-disk area | 1723396.152 mm² | 478964.604 mm² | -72.208% |
| Rigid-body length | 2031.0000001 mm | 1675.4000001 mm | -355.600 mm |
| Ready-to-throw axial length | 2031.0000001 mm | 1675.4000001 mm | -355.600 mm |
| Total STOWED mass | 12.187491464 kg | 13.051842931 kg | +0.864351467 kg |
| Axial CG | 581.837895 mm | 618.355733 mm | +36.517839 mm |
| Radial CG | 0.131113 mm | 0.313695 mm | +0.182582 mm |

The shorter arms and body reduce ready-state length, deployed reach, and rotational inertia. They do **not** establish equivalent fabric engagement, snag behavior, retention, or extraction. The idealized disk is a geometric comparison only; it is not parachute-contact performance evidence.

Required status: **PHYSICAL FABRIC-ENGAGEMENT, SNAG, RETENTION, AND EXTRACTION TEST REQUIRED**.

Fall/orientation status: **QUANTITATIVE FALL/ORIENTATION EQUIVALENCE REMAINS A SEPARATE VERIFICATION ITEM**.
