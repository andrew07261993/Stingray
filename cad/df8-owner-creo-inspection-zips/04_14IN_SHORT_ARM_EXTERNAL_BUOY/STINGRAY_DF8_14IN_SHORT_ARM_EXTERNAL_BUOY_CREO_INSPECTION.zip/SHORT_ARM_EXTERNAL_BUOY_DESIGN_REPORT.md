# Short-Arm External-Buoy Design Report

## Result

14-INCH SHORT-ARM / SHORT-BODY EXTERNAL-BUOY DEVELOPMENTAL CAD COMPLETE — READY FOR OWNER CREO INSPECTION

The separate developmental variant preserves the validated 480.000 mm nose-to-pivot station and unaffected forward mechanism while shortening each arm by exactly 355.600 mm and the rigid body by exactly 355.600 mm. The complete dedicated internal buoy storage/ejection/control-route chain is absent. A symmetric four-module external inflation subsystem is attached directly to reinforced buoy manifold proxies inside an aft Cordura breakaway wrap.

## Exact configuration

- Arm length: 378.206000 mm (733.806 mm baseline)
- Rigid length: 1675.4000001 mm (2031.0000001 mm baseline)
- Rigid OD: 57.000 mm
- Closed wrap OD: 128.000 mm; maximum ready-state OD including pull tabs: 152.400 mm
- Pack axial extent: 305.000 mm, wholly inside the shortened rigid axial envelope
- Inflation: 4 × UML MK5 UMA4012/D160 path at 60.0 g nominal CO₂ each (240.0 g total)
- Dedicated ejector removals: 57 occurrences / 31 definitions / 0.396484760 kg
- Ready-state mass: 13.051842931 kg; reserve 5.088157069 kg
- Ready-state CG: axial 618.355733 mm; radial 0.313695 mm

## Mechanical architecture

The arm root, pivot bores, bushings, pins, carrier, common crosshead, links, GS-19, HBD-15, arm backup spring, stops, deployed locks and stowed retention are inherited from `a31fce0e768f354b1831331bc2ed145223c8b2c4`. Only the outboard arm blade length and finished tip station change. The former ejector bay becomes a sealed short aft structure with a solid route-closure ring, two shell segments, a one-piece recovery-yoke ring, three clocked primary longerons and a welded closure.

The external pack is anchored through eight occurrence-specific titanium eyes welded to the retained aft-repack shell. Two closed structural webbing loops carry pack retention; Cordura flaps and hook-and-loop do not carry recovery load. Recovery passes from the buoy harness through captive thimbles/pins and the HMPE tether into the integral hardpoint ring and rigid body.

Automatic buoy inflation is independent of the retained body-mounted arm trigger. Four direct open-mesh paths expose four automatic activator proxies while packed. Four independent manual pull lanyards terminate in externally accessible, anti-snag-kept tabs. Buoy expansion loads two opposed peel fronts and leaves the pack attached.

## Validation boundary

Both AP242 endpoints clean-reimported with named hierarchy, millimetres, 0 invalid solids and 0 faceted BREP. The changed-part exact audit found 0 unauthorized rigid interferences after one focused correction. Five-angle and full 81-state arm-motion audits pass. Functional water/manual/opening screens pass as developmental geometry/force screens.

No claim of unchanged parachute engagement, fall behavior, mission performance, commercial-module qualification, exact proprietary geometry, purchased configuration, CoC, or received-item identity is made. See `VALIDATION_SUMMARY.md` and the proxy/register files for the open physical, vendor and procurement gates.
